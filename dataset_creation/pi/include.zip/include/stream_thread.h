#ifndef STREAM_THREAD_H
#define STREAM_THREAD_H

void* stream_thread(void* p_ctx);

#endif // STREAM_THREAD_H
